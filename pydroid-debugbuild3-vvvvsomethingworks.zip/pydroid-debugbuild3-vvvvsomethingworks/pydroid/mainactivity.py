from main import *
app =app()
app.Toast("This is a toast",TOAST_LENGTH.LONG)
tv = TextView("textview")
tv.setAllCaps(False)
tv.setCursorVisible(True)
tv.setTextColor("#432085")
tv.setTextIsSelectable(True)
tv.setTextSize(28)