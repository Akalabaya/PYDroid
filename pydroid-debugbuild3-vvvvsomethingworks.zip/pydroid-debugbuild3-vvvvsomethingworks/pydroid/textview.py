
class TextView:
    def __init__(self,textview):
        self.textview = textview
        string = """TextView """ +self.textview+ """ = findViewById(R.id."""+str(self.textview)+""");\n"""
        app = open("build_token/main.md","ab")    
        app.write((string).encode())
    def settext(self,text):
        string = self.textview+""".setText(" """ +text+ """ " ); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setAllCaps(self,boolean):
        string =  self.textview+""".setAllCaps("""+str(boolean).lower()+"""); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setAutoLinkMask(self,integer):
        string =  self.textview+""".setAutoLinkMask("""+str(integer)+"""); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setCursorVisible(self,boolean):
        string =  self.textview+""".setCursorVisible("""+str(boolean).lower()+"""); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setTextColor(self,hex_code):
        string =  self.textview+""".setTextColor(Color.parseColor(" """ +hex_code+ """ ".trim())); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setTextCursorDrawable(self,resource_id_string):
        string =  self.textview+""".setTextCursorDrawable(R.drawable.""" +resource_id_string+ """); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setTextIsSelectable(self,boolean):
        string =  self.textview+""".setTextIsSelectable(""" +str(boolean).lower()+ """); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setTextKeepState(self,string_char_sequence):
        string =  self.textview+""".setTextKeepState(" """ + string_char_sequence + """ "); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode())
    def setTextSelectHandle(self,resource_id_string):
        string =  self.textview+""".setTextSelectHandle(R.drawable.""" + resource_id_string + """); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode())
    def setTextSize(self,float_or_int):
        string =  self.textview+""".setTextSize(""" + str(float_or_int) + """); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode())




