
package com.akapworldwide.hostkda.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
Toast.makeText(this, " This is a toast ", Toast.LENGTH_SHORT).show();
TextView textview = findViewById(R.id.textview);
textview.setAllCaps(false); 
textview.setCursorVisible(true); 
textview.setTextColor(Color.parseColor(" #432085 ".trim())); 
textview.setTextIsSelectable(true); 
textview.setTextSize(28); 


     }
}
  