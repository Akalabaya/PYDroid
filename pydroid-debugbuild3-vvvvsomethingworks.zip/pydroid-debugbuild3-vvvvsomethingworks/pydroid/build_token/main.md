Toast.makeText(this, " This is a toast ", Toast.LENGTH_SHORT).show();
TextView textview = findViewById(R.id.textview);
textview.setAllCaps(false); 
textview.setCursorVisible(true); 
textview.setTextColor(Color.parseColor(" #432085 ".trim())); 
textview.setTextIsSelectable(true); 
textview.setTextSize(28); 
