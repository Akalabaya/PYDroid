#Initalizing program chars
upper_text = """
package com.akapworldwide.hostkda.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 """

lower_text="""
     }
}
  """
middle_text=open("build_token/main.md","rb").read()
all_string=upper_text+"\n"+middle_text.decode()+"\n"+lower_text
path="package//app//src//main//java//com//akapworldwide//hostkda//myapplication//MainActivity.java"
open(path,"wb").write(all_string.encode())