from textview import *
class TOAST_LENGTH:
    SHORT = "Toast.LENGTH_SHORT"
    LONG = "Toast.LENGTH_LONG"
class app:
    def __init__(self):
        open("build_token/main.md","wb").write("".encode())
    def Toast(self,text,length):
        app = open("build_token/main.md","ab")    
        app.write(('Toast.makeText(this, " '+text+' ", Toast.LENGTH_SHORT).show();\n').encode()) 
        
        