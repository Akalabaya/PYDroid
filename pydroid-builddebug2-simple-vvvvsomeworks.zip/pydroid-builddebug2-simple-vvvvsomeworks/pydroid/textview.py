
class TextView:
    def __init__(self,textview):
        self.textview = textview
        string = """TextView """ +self.textview+ """ = findViewById(R.id."""+str(self.textview)+""");\n"""
        app = open("build_token/main.md","ab")    
        app.write((string).encode())
    def settext(self,text):
        string = self.textview+""".setText(" """ +text+ """ " ); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setAllCaps(self,boolean):
        string =  self.textview+""".setAllCaps("""+str(boolean).lower()+"""); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setAutoLinkMask(self,integer):
        string =  self.textview+""".setAutoLinkMask("""+str(integer)+"""); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 
    def setTextAppearance(self,resid):
        string = self.textview+""".setTextAppearance( """ +resid+ """  ); \n"""

        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 




        