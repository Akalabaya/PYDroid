
package com.akapworldwide.hostkda.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
Toast.makeText(this, " Hi how are you?? ", Toast.LENGTH_SHORT).show();
TextView textview = findViewById(R.id.textview);
textview.setText(" 2nd New text set!!! " ); 
textview.setAllCaps(true); 
textview.setAutoLinkMask(20); 
textview.setTextAppearance();


     }
}
  