from main import *
app = app()
app.Toast("Hi how are you??",TOAST_LENGTH.SHORT)
Tv = TextView("textview")
Tv.settext("2nd New text set!!!")
Tv.setAllCaps(True)
Tv.setAutoLinkMask(20)
Tv.append("Hope you are fine")