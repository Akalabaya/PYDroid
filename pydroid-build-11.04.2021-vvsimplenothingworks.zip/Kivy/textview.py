
class TextView:
    def __init__(self):
        pass
    def settext(self,id,text):
        string = """
         TextView """ +id+ """ = findViewById(R.id."""+id+""");
        """+id+""".setText(" """ + text + """ ");
         """
        app = open("build_token/main.md","ab")    
        app.write((string).encode()) 



        