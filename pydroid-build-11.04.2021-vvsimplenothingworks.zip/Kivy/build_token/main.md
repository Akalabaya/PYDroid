Toast.makeText(this, " Hi how are you?? ", Toast.LENGTH_SHORT).show();
         TextView textview = findViewById(R.id.textview);
        textview.setText(" New text set!!! ");
         