from main import *
app = app()
app.Toast("Hi how are you??",TOAST_LENGTH.SHORT)
Tv = TextView()
Tv.settext("textview","New text set!!!")